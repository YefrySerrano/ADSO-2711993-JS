const swith = document.querySelector(".switch");



